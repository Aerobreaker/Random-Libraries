#include <wx/wx.h>

/*
//////////////////////////////////////////////////////////////////////////////
//To prepare wxWidgets (for visual studio)                                  //
//////////////////////////////////////////////////////////////////////////////
    1. Go to https://www.wxwidgets.org/downloads/ and download the appropriate
       version.  Installer is preferred
    2. Install somewhere other than under C:\Program Files
    3. (Optional) Create an environment variable (WXWIN) which maps to the
       install directory
    4. Open a visual studio command prompt (either by start menu shortcut or
       by opening visual studio and navigating to Tools->Command Line->
       Developer Command Prompt)
    5. Run the following commands:
            For static libraries (no need to ship libraries, but larger file):
                cd %wxwin%\build\msw && nmake /f makefile.vc RUNTIME_LIBS=static CFG=_debug
                cd %wxwin%\build\msw && nmake /f makefile.vc RUNTIME_LIBS=static BUILD=release CFG=_release
                cd %wxwin%\build\msw && "%vcinstalldir%auxiliary\build\vcvars64.bat" && nmake /f makefile.vc RUNTIME_LIBS=static TARGET_CPU=X64 CFG=_debug
                cd %wxwin%\build\msw && "%vcinstalldir%auxiliary\build\vcvars64.bat" && nmake /f makefile.vc RUNTIME_LIBS=static TARGET_CPU=X64 BUILD=release CFG=_release
            For dynamic libraries (smaller file, but need to ship libraries):
                cd %wxwin%\build\msw && nmake /f makefile.vc CFG=_debug
                cd %wxwin%\build\msw && nmake /f makefile.vc BUILD=release CFG=_release
                cd %wxwin%\build\msw && "%vcinstalldir%auxiliary\build\vcvars64.bat" && nmake /f makefile.vc TARGET_CPU=X64 CFG=_debug
                cd %wxwin%\build\msw && "%vcinstalldir%auxiliary\build\vcvars64.bat" && nmake /f makefile.vc TARGET_CPU=X64 BUILD=release CFG=_release
            NOTE:
                The location of vcvars64.bat seems to change between visual
                studio versions.  These instructions are written for visual
                studio 2019 and visual studio 2022.

A single block that can be copied and pasted to build all 8 variants at once:
cd %wxwin%\build\msw
nmake /f makefile.vc SHARED=0 RUNTIME_LIBS=static BUILD=debug CFG=_debug
nmake /f makefile.vc SHARED=1 RUNTIME_LIBS=dynamic BUILD=debug CFG=_debug
nmake /f makefile.vc SHARED=0 RUNTIME_LIBS=static BUILD=release CFG=_release
nmake /f makefile.vc SHARED=1 RUNTIME_LIBS=dynamic BUILD=release CFG=_release
"%vcinstalldir%auxiliary\build\vcvars64.bat"
nmake /f makefile.vc SHARED=0 RUNTIME_LIBS=static TARGET_CPU=X64 BUILD=debug CFG=_debug
nmake /f makefile.vc SHARED=1 RUNTIME_LIBS=dynamic TARGET_CPU=X64 BUILD=debug CFG=_debug
nmake /f makefile.vc SHARED=0 RUNTIME_LIBS=static TARGET_CPU=X64 BUILD=release CFG=_release
nmake /f makefile.vc SHARED=1 RUNTIME_LIBS=dynamic TARGET_CPU=X64 BUILD=release CFG=_release

*/

class MyApp : public wxApp {
public:
    virtual bool OnInit();
};

class MyFrame : public wxFrame {
public:
    MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);
private:
    void OnHello(wxCommandEvent& event);
    void OnExit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);
};

enum {
    ID_Hello = wxID_HIGHEST + 1
};

wxIMPLEMENT_APP(MyApp);

bool MyApp::OnInit() {
    MyFrame* frame = new MyFrame("Hello World", wxPoint(50, 50), wxSize(450, 340));
    frame->Show(true);
    return wxApp::OnInit();
}

MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
    : wxFrame(NULL, wxID_ANY, title, pos, size) {
    wxMenu* menuFile = new wxMenu;
    menuFile->Append(ID_Hello, "&Hello...\tCtrl-H",
        "Help string shown in status bar for this menu item");
    menuFile->AppendSeparator();
    menuFile->Append(wxID_EXIT);
    wxMenu* menuHelp = new wxMenu;
    menuHelp->Append(wxID_ABOUT);
    wxMenuBar* menuBar = new wxMenuBar;
    menuBar->Append(menuFile, "&File");
    menuBar->Append(menuHelp, "&Help");
    SetMenuBar(menuBar);

    CreateStatusBar();
    SetStatusText("Welcome to wxWidgets!");

    Bind(wxEVT_MENU, &MyFrame::OnHello, this, ID_Hello);
    Bind(wxEVT_MENU, &MyFrame::OnExit, this, wxID_EXIT);
    Bind(wxEVT_MENU, &MyFrame::OnAbout, this, wxID_ABOUT);
}

void MyFrame::OnExit(wxCommandEvent& event) {
    Close(true);
}

void MyFrame::OnAbout(wxCommandEvent& event) {
    wxMessageBox("This is a wxWidgets' Hello world sample",
        "About Hello World", wxOK | wxICON_INFORMATION);
}

void MyFrame::OnHello(wxCommandEvent& event) {
    wxLogMessage("Hello world from wxWidgets!");
}

/*
//////////////////////////////////////////////////////////////////////////////
//To replicate this project without using templates                         //
//////////////////////////////////////////////////////////////////////////////
    1. Create new GUI project in visual studio
    2. Open project properties
    3. Under VC++ Directories -> Include Directories, add:
            $(WXWIN)\include\msvc
            $(WXWIN)\include
    4. Under VC++ Directories -> Library Directories, add the appropriate from
       the following:
            32-bit configurations:
                Debug:
                    $(WXWIN)\lib\vc_lib_debug
                Release:
                    $(WXWIN)\lib\vc_lib_release
            64-bit configurations:
                Debug:
                    $(WXWIN)\lib\vc_x64_lib_debug
                Release:
                    $(WXWIN)\lib\vc_x64_lib_release
    5. Under C/C++ -> Proprocessor -> Preprocessor Definitions, add:
            __WXMSW__
    6. Under C/C++ -> Preprocessor -> Preprocessor Definitions, add the
       appropriate from the following:
            For debug configurations:
                wxCFG=_debug
            For release configurations:
                wxCFG=_release
    7. Under C/C++ -> Code Generation -> Runtime Library, change to appropriate:
            If using static libraries:
                Multi-threaded Debug for debug configurations
                Multi-threaded for release configurations
            If using dynamic libraries:
                Multi-threaded Debug DLL for debug configurations
                Multi-threaded DLL for release configurations
*/
