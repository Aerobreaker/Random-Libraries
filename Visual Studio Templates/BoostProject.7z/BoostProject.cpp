#include <boost/lambda/lambda.hpp>
#include <boost/regex.hpp>
#include <iostream>
#include <iterator>
#include <algorithm>
#include <string>

/*
To install boost:
1. Download boost from boost.org
2. Extract, set environment variable %boostdir% for easy locating
3. Run these commands:
"%boostdir%\bootstrap"
"%boostdir%\b2" variant=debug,release address-model=32,64 link=static runtime-link=static
*/

void lambdatest();
void regextest();
void displayusage();

int main(int argc, char* argv[]) {

    if (argc < 2) {
        displayusage();
        return 0;
    }

    std::string arg (argv[1]);

    int tst = ((arg == "lambda") << 1) + (arg == "regex");

    switch (tst) {
    case 1:
        regextest();
        break;
    case 2:
        lambdatest();
        break;
    default:
        displayusage();
    }

    return 0;
}

void lambdatest() {
    typedef std::istream_iterator<int> in;

    std::for_each(in(std::cin), in(), std::cout << (boost::lambda::_1 * 3) << " ");
}

void regextest() {
    std::string line;
    boost::regex pat("^Subject: (Re: | Aw: )*(.*)");

    while (std::cin) {
        std::getline(std::cin, line);
        boost::smatch matches;
        if (boost::regex_match(line, matches, pat)) {
            std::cout << matches[2] << std::endl;
        }
    }
}

void displayusage() {
    using namespace std;
    cout << "Usage:" << endl;
    cout << "  echo\\some numbers here | %path/to/file.exe% lambda" << endl;
    cout << "-or-" << endl;
    cout << "  %path/to/file.exe% regex < %path/to/email/formatted/file.txt%" << endl;
}

/*
To replicate this project without a template:
Add to include paths:
$(boostdir)
Add to linker lib paths:
$(boostdir)\stage\lib
*/
